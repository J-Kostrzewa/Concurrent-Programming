# Concurrent programming

## Working Group

| Name Surname (initials) | GUID                                     |
| ----------------------- | ---------------------------------------- |
| JK                      | `{55D32494-E31C-4025-B0E0-5F99F7A4640E}` |
| MI                      | `{F07CF04E-0D2D-4D61-A712-C6897BDBF317}` |
